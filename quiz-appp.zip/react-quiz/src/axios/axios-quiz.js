import axios from 'axios'

export default axios.create({
  baseURL: 'https://react-quiz-468e0.firebaseio.com/'
})

